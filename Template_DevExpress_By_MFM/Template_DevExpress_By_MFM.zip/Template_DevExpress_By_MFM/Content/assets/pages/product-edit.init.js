/*
 Template Name: Veltrix - Responsive Bootstrap 4 Admin Dashboard
 Author: Themesbrand
 File: Product Edit Init
*/

// Select2
$(".select2").select2();
